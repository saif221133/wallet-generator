import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Container, CssBaseline, ThemeProvider, createTheme } from '@material-ui/core';
import HomePage from './pages/HomePage';
import WalletPage from './pages/WalletPage';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

const theme = createTheme({
  palette: {
    primary: {
      main: '#3f51b5',
    },
    secondary: {
      main: '#f50057',
    },
    background: {
      default: '#f5f5f5',
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Navbar />
      <Container maxWidth="lg" style={{ marginTop: '20px', marginBottom: '20px' }}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/wallet/:address" element={<WalletPage />} />
        </Routes>
      </Container>
      <Footer />
    </ThemeProvider>
  );
}

export default App;