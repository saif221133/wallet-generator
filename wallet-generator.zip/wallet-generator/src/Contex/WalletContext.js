import React, { createContext, useState, useEffect } from 'react';
import * as bitcoin from 'bitcoinjs-lib';
import * as bip39 from 'bip39';
import { ethers } from 'ethers';
import axios from 'axios';

export const WalletContext = createContext();

export const WalletProvider = ({ children }) => {
  const [wallets, setWallets] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('btc');
  const [transactions, setTransactions] = useState([]);

  const networks = {
    btc: { name: 'Bitcoin', symbol: 'BTC' },
    eth: { name: 'Ethereum', symbol: 'ETH' },
    bsc: { name: 'Binance Smart Chain', symbol: 'BNB' },
    matic: { name: 'Polygon', symbol: 'MATIC' },
  };

  const generateWallet = async (network) => {
    setIsLoading(true);
    try {
      const mnemonic = bip39.generateMnemonic();
      let walletData;

      if (network === 'btc') {
        const seed = await bip39.mnemonicToSeed(mnemonic);
        const root = bitcoin.bip32.fromSeed(seed);
        const path = "m/44'/0'/0'/0/0";
        const child = root.derivePath(path);
        
        const { address } = bitcoin.payments.p2pkh({
          pubkey: child.publicKey,
          network: bitcoin.networks.bitcoin,
        });

        walletData = {
          network,
          address,
          privateKey: child.toWIF(),
          mnemonic,
          balance: 0
        };
      } else {
        const wallet = ethers.Wallet.fromMnemonic(mnemonic);
        
        walletData = {
          network,
          address: wallet.address,
          privateKey: wallet.privateKey,
          mnemonic,
          balance: 0
        };
      }

      setWallets(prev => [...prev, walletData]);
      return walletData;
    } catch (error) {
      console.error('Error generating wallet:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const checkBalance = async (wallet) => {
    try {
      let balance;
      
      if (wallet.network === 'btc') {
        const response = await axios.get(
          `https://blockchain.info/balance?active=${wallet.address}`
        );
        balance = response.data[wallet.address].final_balance / 100000000;
      } else {
        let apiUrl;
        switch(wallet.network) {
          case 'eth':
            apiUrl = `https://api.etherscan.io/api?module=account&action=balance&address=${wallet.address}&tag=latest&apikey=YOUR_ETHERSCAN_API_KEY`;
            break;
          case 'bsc':
            apiUrl = `https://api.bscscan.com/api?module=account&action=balance&address=${wallet.address}&tag=latest&apikey=YOUR_BSCSCAN_API_KEY`;
            break;
          case 'matic':
            apiUrl = `https://api.polygonscan.com/api?module=account&action=balance&address=${wallet.address}&tag=latest&apikey=YOUR_POLYGONSCAN_API_KEY`;
            break;
        }
        
        const response = await axios.get(apiUrl);
        balance = ethers.utils.formatEther(response.data.result);
      }

      return parseFloat(balance).toFixed(6);
    } catch (error) {
      console.error('Error checking balance:', error);
      return 0;
    }
  };

  const fetchTransactions = async (address, network) => {
    try {
      let apiUrl;
      
      switch(network) {
        case 'btc':
          apiUrl = `https://blockchain.info/rawaddr/${address}`;
          break;
        case 'eth':
          apiUrl = `https://api.etherscan.io/api?module=account&action=txlist&address=${address}&startblock=0&endblock=99999999&sort=desc&apikey=YOUR_ETHERSCAN_API_KEY`;
          break;
        case 'bsc':
          apiUrl = `https://api.bscscan.com/api?module=account&action=txlist&address=${address}&startblock=0&endblock=99999999&sort=desc&apikey=YOUR_BSCSCAN_API_KEY`;
          break;
        case 'matic':
          apiUrl = `https://api.polygonscan.com/api?module=account&action=txlist&address=${address}&startblock=0&endblock=99999999&sort=desc&apikey=YOUR_POLYGONSCAN_API_KEY`;
          break;
      }
      
      const response = await axios.get(apiUrl);
      let txs = [];
      
      if (network === 'btc') {
        txs = response.data.txs.map(tx => ({
          hash: tx.hash,
          from: tx.inputs.map(input => input.prev_out.addr).join(', '),
          to: tx.out.map(output => output.addr).join(', '),
          value: tx.result / 100000000,
          timestamp: tx.time,
          confirmations: tx.block_height
        }));
      } else {
        txs = response.data.result.map(tx => ({
          hash: tx.hash,
          from: tx.from,
          to: tx.to,
          value: ethers.utils.formatEther(tx.value),
          timestamp: tx.timeStamp,
          confirmations: tx.confirmations
        }));
      }
      
      setTransactions(txs);
      return txs;
    } catch (error) {
      console.error('Error fetching transactions:', error);
      return [];
    }
  };

  return (
    <WalletContext.Provider
      value={{
        wallets,
        generateWallet,
        checkBalance,
        isLoading,
        activeTab,
        setActiveTab,
        networks,
        transactions,
        fetchTransactions
      }}
    >
      {children}
    </WalletContext.Provider>
  );
};