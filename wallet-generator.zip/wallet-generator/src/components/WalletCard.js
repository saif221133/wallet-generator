import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { WalletContext } from '../context/WalletContext';
import { Card, CardContent, Typography, Button, Box } from '@material-ui/core';
import QRCode from 'react-qr-code';

const WalletCard = ({ wallet }) => {
  const { networks } = useContext(WalletContext);
  const navigate = useNavigate();

  return (
    <Card>
      <CardContent>
        <Box display="flex" justifyContent="space-between">
          <Box>
            <Typography color="textSecondary" gutterBottom>
              {networks[wallet.network].name}
            </Typography>
            <Typography variant="h5" component="h2" style={{ fontFamily: 'monospace' }}>
              {wallet.address.substring(0, 10)}...
            </Typography>
            <Typography color="textSecondary">
              Balance: {wallet.balance || 0} {networks[wallet.network].symbol}
            </Typography>
          </Box>
          <QRCode value={wallet.address} size={80} />
        </Box>
        <Box mt={2}>
          <Button
            size="small"
            variant="outlined"
            onClick={() => navigate(`/wallet/${wallet.address}`)}
          >
            View Details
          </Button>
        </Box>
      </CardContent>
    </Card>
  );
};

export default WalletCard;