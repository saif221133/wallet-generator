import React, { useContext, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { WalletContext } from '../context/WalletContext';
import { Box, Button, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from '@material-ui/core';
import QRCode from 'react-qr-code';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import FileCopyIcon from '@material-ui/icons/FileCopy';

const WalletPage = () => {
  const { address } = useParams();
  const { wallets, checkBalance, fetchTransactions, networks } = useContext(WalletContext);
  const [wallet, setWallet] = useState(null);
  const [balance, setBalance] = useState(0);
  const [transactions, setTransactions] = useState([]);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const foundWallet = wallets.find(w => w.address === address);
    if (foundWallet) {
      setWallet(foundWallet);
      loadData(foundWallet);
    }
  }, [address, wallets]);

  const loadData = async (wallet) => {
    const balance = await checkBalance(wallet);
    setBalance(balance);
    
    const txs = await fetchTransactions(wallet.address, wallet.network);
    setTransactions(txs);
  };

  if (!wallet) {
    return <Typography>Wallet not found</Typography>;
  }

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        {networks[wallet.network].name} Wallet Details
      </Typography>
      
      <Box display="flex" justifyContent="space-between" mb={4} flexWrap="wrap">
        <Box>
          <Typography variant="h6">Address:</Typography>
          <Box display="flex" alignItems="center">
            <Typography style={{ fontFamily: 'monospace' }}>{wallet.address}</Typography>
            <CopyToClipboard text={wallet.address} onCopy={() => setCopied(true)}>
              <Button size="small" startIcon={<FileCopyIcon />}>
                {copied ? 'Copied!' : 'Copy'}
              </Button>
            </CopyToClipboard>
          </Box>
          
          <Typography variant="h6" mt={2}>Balance:</Typography>
          <Typography>
            {balance} {networks[wallet.network].symbol}
          </Typography>
          
          <Typography variant="h6" mt={2}>Private Key:</Typography>
          <Typography style={{ fontFamily: 'monospace', wordBreak: 'break-all' }}>
            {wallet.privateKey}
          </Typography>
          
          <Typography variant="h6" mt={2}>Mnemonic Phrase:</Typography>
          <Typography style={{ fontFamily: 'monospace', wordBreak: 'break-all' }}>
            {wallet.mnemonic}
          </Typography>
        </Box>
        
        <Box>
          <QRCode value={wallet.address} size={200} />
        </Box>
      </Box>
      
      <Typography variant="h5" gutterBottom>
        Transaction History
      </Typography>
      
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Tx Hash</TableCell>
              <TableCell>From</TableCell>
              <TableCell>To</TableCell>
              <TableCell>Value</TableCell>
              <TableCell>Confirmations</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {transactions.map((tx, index) => (
              <TableRow key={index}>
                <TableCell style={{ fontFamily: 'monospace', maxWidth: '150px', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {tx.hash}
                </TableCell>
                <TableCell style={{ fontFamily: 'monospace', maxWidth: '150px', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {tx.from}
                </TableCell>
                <TableCell style={{ fontFamily: 'monospace', maxWidth: '150px', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {tx.to}
                </TableCell>
                <TableCell>
                  {tx.value} {networks[wallet.network].symbol}
                </TableCell>
                <TableCell>
                  {tx.confirmations}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default WalletPage;