import React, { useContext, useEffect } from 'react';
import { WalletContext } from '../context/WalletContext';
import { Box, Button, Grid, Paper, Tab, Tabs, Typography } from '@material-ui/core';
import WalletCard from '../components/WalletCard';
import QRCode from 'react-qr-code';

const HomePage = () => {
  const {
    wallets,
    generateWallet,
    checkBalance,
    isLoading,
    activeTab,
    setActiveTab,
    networks
  } = useContext(WalletContext);

  const filteredWallets = wallets.filter(wallet => wallet.network === activeTab);

  const handleGenerate = async () => {
    const wallet = await generateWallet(activeTab);
    if (wallet) {
      const balance = await checkBalance(wallet);
      wallet.balance = balance;
    }
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Multi-Coin Wallet Generator
      </Typography>
      
      <Paper style={{ marginBottom: '20px' }}>
        <Tabs
          value={activeTab}
          onChange={(e, newValue) => setActiveTab(newValue)}
          indicatorColor="primary"
          textColor="primary"
          variant="scrollable"
          scrollButtons="auto"
        >
          {Object.entries(networks).map(([key, network]) => (
            <Tab key={key} label={network.name} value={key} />
          ))}
        </Tabs>
      </Paper>
      
      <Box mb={3}>
        <Button
          variant="contained"
          color="primary"
          onClick={handleGenerate}
          disabled={isLoading}
        >
          {isLoading ? 'Generating...' : `Generate ${networks[activeTab].name} Wallet`}
        </Button>
      </Box>
      
      <Grid container spacing={3}>
        {filteredWallets.map((wallet, index) => (
          <Grid item xs={12} sm={6} md={4} key={index}>
            <WalletCard wallet={wallet} />
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default HomePage;